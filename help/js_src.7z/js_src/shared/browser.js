define(['./js-helper'], function(hp){
    var support_rem = null;
    var support_chartjs = null;
    
    function initBrowserInfo(){
        var is_ie = hp.isIE();
        var version = hp.getBrowserVersion();
        
        if (is_ie && (version <= 8.0)) {
            support_rem = false;
        } else {
            support_rem = true;
        }
    
        if ((is_ie && version >= 10.0) || !(is_ie)) {
            support_chartjs = true;
        }
        else
        {
            support_chartjs = false;
        }
    }
    
    initBrowserInfo();
    
    return {
        isSupportRem: function(){
            return support_rem;
        },
        isSupportChartJs: function(){
            return support_chartjs;
        },
        
        getWidth: function(){
            return hp.getWindowWidth();
        },
        
        getHeight: function(){
            return hp.getWindowHeight();
        }
        
    }
})