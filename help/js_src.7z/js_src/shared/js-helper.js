define(['jquery'], function($){
    
    function Selector(s){
        var target = $(s);
        
        return {
            getElement: function(idx){
                return target[idx];
            },
            
            append: function(dom){
                target.append(dom);
            },
            
            hide: function(speed,callback){
                target.hide(speed, callback);
            },
            
            show: function(speed, callback){
                target.show(speed, callback);
            },
            
            getAttr: function(attribute){
                return target.attr(attribute);
            },
            
            setAttr: function(attribute, value){
                target.attr(attribute, value);
            },
            
            getCss: function(attribute){
                return target.css(attribute);
            },
            
            setCss: function(attribute, value){
                target.css(attribute, value);
            },
            
            removeClassWith: function(s){
                var cls = this.getAttr('class');
                var cls_idx = cls.indexOf(s);
                if (cls_idx != -1){
                    var sp_idx = cls.indexOf(' ', cls_idx);
                    
                    if(sp_idx == -1){
                        this.removeClass(cls.substr(cls_idx));
                    }else{
                        this.removeClass(cls.substr(cls_idx, sp_idx-cls_idx+1));
                    }
                }
            },
            
            removeClass: function(s){
                target.removeClass(s);
            },
            
            addClass: function(s){
                target.addClass(s);
            },
            
            getText: function(){
                return target.text();
            },
            
            setText: function(value){
                return target.text(value);
            },
            
            getHtml: function(){
                return target.html();
            },
            
            setHtml: function(value){
                return target.html(value);
            },
            
            is: function(value){
                return target.is(value);
            },
            
            parent: function(){
                return Selector(target.parent());
            },
            
            getChilrens: function(){
                
                var arr = [];
                
                var tmp = target.children();
                for (var i = 0; i < tmp.length; ++i){
                    arr.push(Selector(tmp[i]));
                }
                
                return arr;
            },
            
            getChildren: function(idx){
                var childrens = this.getChilrens();
                
                return childrens[idx];
            },
            
            fadeToggle: function(speed, func){
                return target.fadeToggle(speed, func);
            },
            
            findSuperNode: function(s){
                var count = 0;
                var now = this;
                
                while(!now.is(s)){
                    now = now.parent();
                    
                    if (count++ > 1000) {
                        return null;
                    }
                }
                
                return now;
            },
            
            val: function(){
                return target.val();
            },
            
            innerHeight: function(){
                return target.innerHeight();
            },
            
            height: function(){
                return target.height();
            },
            
            offsetTop: function(){
                return target.offset().top;
            },
            
            toElement: function(){
                return target[0];
            },
            
            length: function(){
                return target.length;
            },
            
            get: function(idx){
                return Selector(target[idx]);
            },
            
            scrollTop: function(value){
                target.scrollTop(value)
            },
            
            animate: function(tb, speed){
                target.animate(tb, speed);
            },
            
            data: function(val){
                return target.data(val);
            }
        };
    }
    
    return {
        sel: function(s){
            return Selector(s);
        },
        
        isIE: function(){
            return $.browser.msie;
        },
        
        getBrowserVersion: function(){
            return $.browser.version;
        },
        
        getWindowWidth: function(){
            return $(window).width();
        },
        
        getWindowHeight: function(){
            return $(window).height()
        },
        
        appendDomTo: function(parent_node, dom){
            this.sel(parent_node).append(dom);
        },
        
        isSmallWebSize: function(){
            var cls = this.sel('html').getAttr('class');
            return cls.indexOf('websize-small') != -1;
        },
        
        setEvent: function(action, name, func){
            $(document).on(action, name, func);
        },
        
        htmlDecode: function(value){
            var html = this.sel('<a></a>').setHtml(value);
            
            return this.sel(html).getText();
        },
        
        htmlEncode: function(value){
            var text = this.sel('<a></a>').setText(value);
            
            return this.sel(text).getHtml();
        },
        
        decodeUrlHash: function(_hash){
            var obj = {};
            
            var ss =  _hash.split('&');
            
            for(var i = 0; i < ss.length; ++i){
                var param = ss[i].split('=');
                var key = param[0];
                var val = decodeURIComponent(param[1]);
                
                obj[key] = val;
            }
            
            return obj;
        },
        
        encodeUrlHash: function(_obj){
            var s = '';
            
            for(var key in _obj){
                s += key;
                s += '=';
                s += encodeURIComponent(_obj[key]);
                s += '&';
            }
            
            return s.substr(0, s.length-1);
        },
        
        ajax: function(url, func){
            $.ajax({
                url: url,
                complete: func
            });
        },
        
        loadDone: function(sel, func){
            var targets = $(sel);
            
            if (targets.length == 0) {
                func();
        
                return;
            }
            
            var defereds = [];

        	targets.each(function () {
        		var dfd = $.Deferred();
        		$(this).bind('load', function () {
        			dfd.resolve();
        		}).bind('error', function () {
        			dfd.resolve();
        		});

        		if (this.complete) setTimeout(function () {
        			dfd.resolve();
        		}, 1000);

        		defereds.push(dfd);
        	})

        	$.when.apply(null, defereds).done(function () {
        		func();
            });
        },
        
        parseJSON: function(s){
            return $.parseJSON(s);
        },
        
        randomColor: function(){
            s = "rgba(";
        	s += String(Math.round(Math.random()*255));
        	s += ", ";
        	s += String(Math.round(Math.random()*255));
        	s += ", ";
        	s += String(Math.round(Math.random()*255));
        	s += ", 0.2";
        	s += ")";
        	
        	return s;
        },
        
        grep: function(arr, func){
            return $.grep(arr, func);
        },
        
        unionArray: function(a, b){
            return a.concat(this.grep(b, function(item){
                if(a.length == 0){
                    return true;
                }
                
                for(var i=0;i<a.length;++i){
                    if(a[i] == item){
                        return false;
                    }
                }

                return true;
            }));  
        }
    }
    
})