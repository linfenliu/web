define(function(){
    require.config({
        baseUrl: './js_src/',
		waitSeconds: 0,
        paths: {
            'jquery': '../../js/jquery.min',
            'chart-js': '../../js/chart.bundle.min',
            'mu_home': '../data/menu',
            'mathjax': '../mathjax/MathJax.js?config=TeX-AMS_HTML-full&amp;delayStartupUntil=configured'
        },
        shim:{
            mu_home:{
                  deps:[],
                  exports: 'mu_home'
            },
            
            mathjax: {
                exports: "MathJax",
                init: function () {
                  MathJax.Hub.Config({
                    extensions: ['tex2jax.js'],
                    tex2jax: {inlineMath: [['$', '$']]},
                    jax: ['input/TeX', 'output/HTML-CSS'],
                    "HTML-CSS": {
                        availableFonts: [],
                        preferredFont: null,
                        webFont: null,
                        styles: {'.MathJax_Preview': {visibility: 'hidden'}}
                    }
                  });
                  MathJax.Hub.Startup.onload();
                  return MathJax;
                }
              }
        }
    });
})