
require(['config', './model/home', './controller/home', './view/home'], function(cfg, model, controller, view){
    view.init('wrap_box', null);
})