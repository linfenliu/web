({
    baseUrl: '../../js_src',
    mainConfigFile: '../config.js',
    name: 'app',
    out: '../../js/app.js',
    
    paths: {
        mu_home: 'empty:',
        jquery: 'empty:',
        'chart-js': 'empty:',
        mathjax: 'empty:'
    },
    
    fileExclusionRegExp: /^(r|build)\.js$/
})