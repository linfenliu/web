define(['mu_home'], function(mu_home){
    
    return {
        getData: function(){
            return mu_home;
        }
        
    }
})