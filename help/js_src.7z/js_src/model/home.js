define(['./mu-home', './mu-map', './nav', './search'], function(mu_home, mu_map, nav, search){
    
    return {
        // 拓扑树
        getMuHomeObj: function(){
            return mu_home;
        },
        
        // 映射表 (name -> obj)
        getMuMapObj: function(){
            return mu_map;
        },
        
        getNavObj: function(){
            return nav;
        },
        
        getSearchObj: function(){
            return search;
        }
    }
})