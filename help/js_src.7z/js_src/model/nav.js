define(['./mu-map'], function(mu_map){
    return {
        generateNav: function(name){
            var nav = [];
            
            var target = mu_map[name];
            if(target != null){
                for (var p = target; p != null; p = p.parent) {
                   nav.push(p);
                }
            }
            
            return nav.reverse();
        }
    }
})