define(['./mu-home'], function(mu_home){
    function generateMuMap(){
        var map = {};
        
        function generateImpl(node, supnode){
            node.parent = supnode;
            map[node.name] = node;
            
            var children = node.children;
            
            for (var i = 0; i < children.length; ++i){
                generateImpl(children[i], node);
            }
        }
        
        generateImpl(mu_home.getData(), null);
        
        return map;
    }
    
    var mu_map = generateMuMap();
    
    return {
        getData: function(){
            return mu_map;
        }
    }
})