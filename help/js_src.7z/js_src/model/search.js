define(['./mu-map', '../shared/js-helper'], function (map, hp) {
    
    return {
        findTextFrom: function(from, text){
            var mu_map = map.getData();
            
            var tmp = [];
            
            for(var i = 0; i < from.length; ++i){
                tmp.push([]);
            }
            
            for (var key in mu_map) {
                var item = mu_map[key];
                
                for(var i = 0; i < from.length; ++i){
                    var target = from[i];
                    
                    if (item[target].indexOf(text) != -1) {
                        tmp[i].push(item);
                    }
                }
            }
            
            var res = [];
            
            for(var i = 0; i < tmp.length; ++i){
                res = hp.unionArray(res, tmp[i])
            }
            
            return res;
        },
        
        findTextFromName: function (text) {
            return this.findTextFrom(['name'], text);
        },

        findTextFromTitle: function (text) {
            return this.findTextFrom(['title'], text);
        },

        findTextFromBody: function (text) {
            return this.findTextFrom(['body'], text);
        }
    }
})