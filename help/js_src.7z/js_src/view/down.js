define(['../controller/home','./maker', '../shared/js-helper', './left', './right'], function(ctrl, mk, hp, left, right){
    
    return mk.extentView({
        init: function(_id, _parent){
            this.setBase(_id, _parent);
            
            var dom = '<div id=\'' + this.id + '\'></div>';
            hp.appendDomTo('#'+this.parent.id, dom);
            
            left.init('wrap_left', this);
            right.init('wrap_right', this);
        },
        
        resizeLayout: function(props){
            
            hp.sel('#'+this.id).setCss('height', props.height);
            
            var left_param = {};
            var right_param = {};
            if(left.getMenu().isHide()){
                left_param.width = 0;
                right_param.left = 0;
                right_param.width = '100%';
            }else{
                if(hp.isSmallWebSize()){
                    props.left = hp.getWindowWidth();
                }
                
                left_param.width = props.left;
                right_param.left = props.left;
                right_param.width = hp.getWindowWidth()-props.left;
            }
            
            left.resizeLayout(left_param);
            right.resizeLayout(right_param);
        },
        
        getLeft: function(){
            return left;
        },
        
        getRight: function(){
            return right;
        }
        
    });
})