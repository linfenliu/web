define(['../controller/home','./maker', '../shared/js-helper', '../model/search'], function(ctrl, mk, hp, search){
    
    
    function makeSearchTitle(mu, value){
            
        function makeSearchLink(){
            return "<a class='"+ " cls_" + mu.name + 
                "' href='#" + mu.name +
                "' flags='" + mu.flags + "'>" + mu.title + "</a>";
        }
        
        var head_html = "";
        
        if (mu.title.indexOf(value) != -1)
        {
            //处理title mark_result_search
            var re = new RegExp(value, "g");
            var pl = "<span class='mark_result_search'>" + value + "</span>";
            
            var cache = mu.title;
            mu.title = mu.title.replace(re, pl);
            head_html = makeSearchLink();
            mu.title = cache;
        }
        else
        {
            head_html = makeSearchLink();
        }
        
        return head_html;
    }
    
    function makeSearchBody(mu, delta, value){
        var src = mu.body;
        var vlen = value.length;
        function findAllIndex()
        {
            var idx = [];
            var st = 0;
            
            while (1)
            {
                var id = src.indexOf(value, st);
                
                if (id == -1) break;
                
                idx.push(id);
                
                st = st + id + vlen;
            }
            
            return idx;
        }
        
        var idx = findAllIndex();
	
        	var body_res = "";
            var body_size = src.length;
            
            if (idx.length > 0)
        	{
        		var cur_box = 0;
        		
        		for (var i = 0, len = idx.length; i < len; ++i)
        		{
        			var fw_margin = idx[i] - cur_box;
        			
        			if (fw_margin > 0)
        			{
        				if (fw_margin > delta)
        				{
        					body_res += "...";
        					body_res += src.substr(idx[i]-delta, delta+vlen);
        				}
        				else
        				{
        					body_res += src.substr(cur_box, idx[i]-cur_box+vlen);
        				}
        				
        				cur_box = idx[i] + vlen;
        			}
        			
        			if (idx[i]+vlen - cur_box > 0)
        			{
        				body_res += src.substr(cur_box ,idx[i]+vlen - cur_box);
        				
        				cur_box = idx[i] + vlen;
        			}
        			
        			if (idx[i]+vlen+delta > cur_box)
        			{
        				var fnl = idx[i]+ delta + vlen;
        				
        				if (fnl > body_size) fnl = body_size;
        				
        				body_res += src.substr(cur_box, fnl - cur_box);
        				
        				cur_box = fnl;
        			}
        			
        			if(cur_box == body_size)
        			{
        				break;
        			}
        		}
        		
        		var re = new RegExp(value, "g");
        		var pl = "<span class='mark_result_search'>" + value + "</span>";
        		body_res = body_res.replace(re, pl);
        	}
        	else
        	{
        		body_res = body_size > 40 ? src.substr(0, 40) : src;
        	}
        	
        	return "<p class='body_result_search'>" + body_res + "</p>";
    }
    
    function addSearchItem(mu, value){
        var s = "<li class='li_result_search'>";
        s += makeSearchTitle(mu, value);
        s += makeSearchBody(mu, 30, value);
        s += "</li>";
        
        hp.sel('.ul_result_search').append(s);
    }
    
    
    return mk.extentView({
        init: function(_id, _parent){
            this.setBase(_id, _parent);
            
            var dom = '<div id=\'' + this.id + '\'></div>';
            hp.appendDomTo('#'+this.parent.id, dom);
        },
        
        generateSearchResult: function(value){
            var res = search.findTextFrom(['name', 'title' ,'body'], value);
            
            hp.sel('#num_result_search').setText(res.length);
            hp.sel('#word_result_search').setText(value);
            
            for (var i = 0; i < res.length; ++i){
                var item = res[i];
                
                addSearchItem(item, value);
            }
        }
    });
})