define(['../controller/home','./maker', '../shared/js-helper', './nav', '../shared/browser', './menu'], function(ctrl, mk, hp, nav,browser, menu){
    
    var tb = mk.extentView({
        
    });
    
    var icon = {
		back: ["后退", "&#xe657"],
		front: ["前进", "&#xe654"],
		text: ["文本", "&#xe71f"],

        style: ["日间", "&#xe60c"],
        style_day: ["日间", "&#xe60c"],
        style_night: ["夜间", "&#xe612"],

		reload: ["重载", "&#xe611"],
		release: ["发布", "&#xe614"],

		expand: ["菜单", "&#xe610"],
		expand_show: ["菜单", "&#xe610"]
	}
    
    function getButtons(){
        var buttons = {};
        
        buttons.left = ['expand'];
        
        if(hp.isSmallWebSize()){
            buttons.right = ["text", "style"];
            
            return buttons;
        }
        
        if(tb.parent.isDebug()){
            if(browser.isSupportRem()){
                buttons.right = ["text", "style", "reload", "release"];
            }else{
                buttons.right = ["reload", "release"];
            }
        }else{
            if(browser.isSupportRem()){
                buttons.right = ["text", "style"];
            }else{
                buttons.right = [];
            }
        }
        
        return buttons;
    }
    
    
    function initButton(btns, parent){
        for(var i = 0; i < btns.length; ++i){
            var btn = btns[i];
            
            var tag = 'button';
            var cls = 'button_top button_' + btn;
            
            var s = '<'+tag+' class=\''+cls+'\'' +'>';
            if(browser.isSupportRem()){
                s += icon[btn][1];
            }else
            {
                s += icon[btn][0];
            }
            s+='</'+tag+'>';
            
            hp.appendDomTo('#'+parent.id, s);
            
            var func = function(_btn){return function(){ctrl.btn_events[_btn](tb)}}(btn);
            hp.setEvent('click', '.button_'+btn, func)
        }
    }
    
    function hideButtons(){
        var sel = hp.sel('.button_top');
        sel.setCss('display', 'none');
    }
    
    function showButtons(buttons, width, delta, start){
        var left_buttons = buttons['left'];
        var right_buttons = buttons['right'];
        
        if(hp.isSmallWebSize()){
            start = 10;
        }
        
        var now_left = start;
        
        for (var i = 0; i < left_buttons.length; ++i){
            var cls = 'button_' + left_buttons[i];
            var sel = hp.sel('.'+cls);
            
            sel.setCss('display', 'block');
            sel.setCss('width', width)
            sel.setCss('left', now_left)
            
            now_left += delta;
        }
        
        var now_right = (right_buttons.length - 1) * delta + start;
        
        for (var i = 0; i < right_buttons.length; ++i){
            var cls = 'button_' + right_buttons[i];
            var sel = hp.sel('.'+cls);
            
            sel.setCss('display', 'block');
            sel.setCss('width', width)
            sel.setCss('right', now_right)
            
            now_right -= delta;
        }
    }
    
    
    tb.init = function(_id, _parent){
        this.setBase(_id, _parent);
        
        var dom = '<div id=\'' + this.id + '\'></div>';
        hp.appendDomTo('#'+this.parent.id, dom);
        
        var buttons = getButtons();
        var left_buttons = buttons['left'];
        var right_buttons = buttons['right'];
        
        initButton(left_buttons, this);
        nav.init('div_navigation', this);
        initButton(right_buttons, this);
        
        showButtons(buttons, 50, 55, 30);
    }
    
    tb.resizeLayout = function(props){
        
        hp.sel('#'+this.id).setCss('height', props.height);
        
        hideButtons();
        showButtons(getButtons(), 50, 55, 30);
    }
    
    tb.getNav = function(){
        return nav;
    }
    
    tb.toggleMenuVisible = function(){
        return menu.toggleMenuVisible();
    }
    
    tb.changeFontSize = function(min, max, delta){
        var sel = hp.sel('html');
        var font_size = sel.getCss('font-size');
        var curr_size = Number(font_size.match(/\d+/));
        var next_size = curr_size + delta;
        
        if (next_size > max) {
            next_size = min;
        }
        
        sel.animate({
            fontSize: String(next_size) + "px"
        }, 'normal')
    }
    
    tb.changeStyle = function(){
        function updateStyleIcon(style){
            var sel = hp.sel('.button_style');
            
            if(browser.isSupportRem()){
                sel.setHtml(icon[style][1]);
            }
            else{
                sel.setHtml(icon[style][0]);
            }
        }
        
        var sel_html = hp.sel('html');
        var cls_html = sel_html.getAttr('class');
        if(cls_html.indexOf('color-theme-') == -1){
            cls_html += ' color-theme-day';
        }
        
        
        if(cls_html.indexOf('color-theme-day') != -1){
            sel_html.removeClassWith('color-theme-');
            sel_html.addClass('color-theme-night');

            updateStyleIcon('style_night');
        }else if(cls_html.indexOf('color-theme-night') != -1){
            sel_html.removeClassWith('color-theme-');
            sel_html.addClass('color-theme-day');
            
            updateStyleIcon('style_day');
        }
    }
    
    return tb;
})