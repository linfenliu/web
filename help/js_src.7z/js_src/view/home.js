define(['../controller/home', './maker', '../shared/js-helper', './up', './down', '../model/home', '../shared/browser'],
function(ctrl, mk, hp, up, down, home, browser){
    
    function updateWebSize(){
        var width = hp.getWindowWidth();
        var web_size = null;
        
        if (width <= 618){
            web_size = 'websize-small';
        }else if(width <=925){
            web_size = 'websize-medium';
        }else if(width > 925){
            web_size = 'websize-large';
        }
        
        var sel = hp.sel('html');
        sel.removeClassWith('websize-');
        sel.addClass(web_size);
    }
    
    function updateMenuState(name){
        var cls_name = '#wrap_menu .cls_' + name;
        var sel = hp.sel(cls_name);
        
        hp.sel('#wrap_menu .cls_menu_active').removeClass('cls_menu_active');
        sel.addClass('cls_menu_active');
        
        
        var self_table = sel.findSuperNode('table');
    	if (self_table) {
    		down.getLeft().getMenu().controlMenu(self_table.parent(), 'expand', 'up', -1);
        }
        var item_innerh = sel.innerHeight();
        var item_offset = sel.offsetTop();
        var frma_height = hp.sel('#'+down.getLeft().id).height();
        
        if (item_offset < item_innerh ||
            item_offset > frma_height) {
                var item = sel.toElement();
                
                if(browser.isSupportRem()){
                    item.scrollIntoView({
                        block: "center"
                    });
                }else{
                    item.scrollIntoView();
                }
        }
    }
    
    function updateNav(target){
        up.getNav().update(target);
    }
    
    function renderChart(item, dat){
        
        function setChartOptions(){
            var data = {
                labels: [],
                datasets: []
            }
            
            data.labels = dat.labels;
            data.datasets = dat.datasets;
            
            dat.data = data;
            
            var options = {
                maintainAspectRatio: false,
                
                elements: {
                    line: {
                        tension: 0.0
                    }
                },
                
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero:false
                        }
                    }],
                    xAxes: [{
                        ticks: {
                            beginAtZero:false
                        }
                    }]
                }
            }
            
            if (dat.beginAtZeroX != null) options.scales.xAxes[0].ticks.beginAtZero = dat.beginAtZeroX;
            if (dat.beginAtZeroY != null) options.scales.yAxes[0].ticks.beginAtZero = dat.beginAtZeroY;
            if (dat.tension != null) options.elements.line.tension = dat.tension;
            
            dat.options = options;
        }
        
        function setChartColors(){
            
            function changeAlpha(col, val)
            {
                return col.substr(0, col.lastIndexOf(",")+1)+" "+String(val)+")";
            }
            
            var dat_size = dat.data.labels.length;
            
        	for (var idx in dat.data.datasets)
        	{
        		if (dat.data.datasets[idx].backgroundColor != null)
        		{
        			continue;
        		}
        		
        		var tmp_col;
        		
        		if (dat.type == "pie" || dat.type == "doughnut" || dat.type == "polarArea")
        		{
        			tmp_col = [];
        			
        			if (idx > 0)
        			{
        				tmp_col = dat.data.datasets[idx-1].backgroundColor;
        			}
        			else
        			{
        				for (var i = 0; i < dat_size; ++i)
        				{
        					tmp_col.push(hp.randomColor());
        				}
        			}
        		}
        		else
        		{
        			tmp_col = hp.randomColor();
        		}
        		
        		dat.data.datasets[idx].backgroundColor = tmp_col;
        		dat.data.datasets[idx].borderWidth = 1;
        		
        		if (Array.isArray(tmp_col))
        		{
        			dat.data.datasets[idx].borderColor = tmp_col.map(function(item){return changeAlpha(item, 1.0)});
        		}
        		else
        		{
        			dat.data.datasets[idx].borderColor = changeAlpha(tmp_col, 1.0);
        		}
        	}
        }
        
        if (browser.isSupportChartJs()){
            require(['chart-js'], function(Chart){
                if (dat.width == null) dat.width = 80;
                if (dat.height == null) dat.height = 60;
                
                setChartOptions();
                setChartColors();
                
                var target = item.parent();
                
                target.setCss("width", String(dat.width)+"%");
                target.setCss("height", String(dat.height)+"vh");
                
                new Chart(item.toElement(), dat);
            })
        }else{
            return false;
        }

        return true;
    }
    
    function loadContentPage(value, keyword){
        var ss = value.split('.');
        
        var name = ss[0];
        var anchor = ss[1];
        
        var mu_map = home.getMuMapObj().getData();
        var target = mu_map[name];
        if(target == null){
            return;
        }
        
        updateMenuState(target.name);
        
        hp.ajax(target.file, function (res) {
            
            var res_html = res.responseText;
            
            if(keyword != null){
                res_html = res.responseText.replace(/>([\d\D]*?)</g, function(){
                    return ">"
                    + arguments[1].replace(new RegExp(keyword, "g"), "<span class='mark_result_search'>"+ keyword +"</span>")
                    + "<";
                });
            }
            
            var cnt = hp.sel('#wrap_content');
            cnt.setHtml(res_html);
            
            // chart-js
            var canvas = hp.sel('canvas');
            
            for(var i = 0; i < canvas.length(); ++i){
                var item = canvas.get(i)
                var data = item.getAttr('data-chart');

                if(data != null && data != ''){
                    var obj = hp.parseJSON(data.replace(/%u/g,'\\u'));
                    if (!renderChart(item, obj)){
                        hp.sel('.chart_wrapper').setHtml('<b style="color: red">当前浏览器版本过低，图表无法正常显示.</b>')

                        break;
                    }
                }
            }
            
            require(['mathjax'], function(){
                window.top.MathJax.Hub.Queue(['Typeset', MathJax.Hub, document.getElementById(down.getRight().getContent().id)]);
            });
            
            window.top.document.title = target.title + ' - EastWave Help';
            updateNav(target);
            
            var load_imgs_done_func = function(){
                if (keyword){
                    hp.sel('.mark_result_search').toElement().scrollIntoView();
                }
                else if(anchor != null && anchor != ''){
                    document.getElementsByName(value)[0].scrollIntoView();
                }else{
                    hp.sel('#'+down.getRight().id).scrollTop(0);
                }
                
                if (hp.isSmallWebSize()){
                    down.getLeft().getMenu().hide();
                }
            }
            
            hp.loadDone('.markdown-body img', load_imgs_done_func);
        });
    }
    
    
    function loadContent(hash){
        var props = hp.decodeUrlHash(hash);
        
        return loadContentPage(props.value, props.keyword);
    }
    
    
    function loadSearchPage(value){
        if (value == null || value == ''){
            return;
        }
        
        hp.ajax('./search.htm', function (res) {
            
            hp.sel('#'+down.getRight().getContent().id).setHtml(res.responseText);
            
            window.top.document.title = '搜索"'+ value + '" - EastWave Help'
            updateNav(home.getMuHomeObj().getData());
            
            down.getRight().getContent().generateSearchResult(value);
            
            hp.sel('#'+down.getRight().id).scrollTop(0);
            
            if (hp.isSmallWebSize()){
                down.getLeft().getMenu().hide();
            }
        });
    }
    
    function loadSearch(hash){
        var props = hp.decodeUrlHash(hash);
        
        var value = props.value;
        
        if(value == null || value== ''){
            return;
        }
        
        if(props.src == 'help'){
            
            var obj_search = home.getSearchObj();
            var names = obj_search.findTextFromName(value);
            
            if(names.length == 1){
                var target = names[0]; 
                
                if(target.name.split("_").pop() == value){
                    return loadContentPage(target.name);
                }
            }
        }
        
        return loadSearchPage(value);
    }

    function adjustUrl(){
        var query = window.top.location.search.replace('?', '');

        if(query!=''){
            var props = hp.decodeUrlHash(query);

            var value = props.value;
            if(value == null || value== ''){
                return;
            }

            var obj_search = home.getSearchObj();
            var names = obj_search.findTextFromName(value);
            
            var url = window.location.href.split('?')[0];
            if(names.length == 1){
                var target = names[0]; 

                if(target.name.split("_").pop() == value){
                    
                    window.location.replace(url + "#" + target.name);
                    return;
                }
            }

            window.location.replace(url + "#search_" + value);
        }
    }
    
    return mk.extentView({
        top_size: 44,
        left_size: 290,
        
        init: function(_id, _parent){
            this.setBase(_id, _parent);
            
            var dom_box = '<div id=\'' + this.id + '\'></div>';
            hp.appendDomTo('body', dom_box);
            
            up.init('wrap_up', this);
            down.init('wrap_down', this);
            
            this.resizeLayout();
            ctrl.resizeEvent(100, this);
            
            adjustUrl();

            ctrl.hashEvent(100, this);
            
            function loadWebDone(){
                hp.sel('.loading').hide();
                hp.sel('#wrap_box').show();
            };
            
            loadWebDone();
        },
        
        resizeLayout: function(props){
            updateWebSize();
            
            if(props == null){
                props = {
                    top: this.top_size,
                    left: this.left_size
                }
            }
            
            var up_param = {};
            up_param.height = props.top;
            up.resizeLayout(up_param);
            
            var down_param = {};
            down_param.left = props.left;
            down_param.height = hp.getWindowHeight()-props.top;
            down.resizeLayout(down_param);
        },
        
        isDebug: function(){
            var cls = hp.sel('html').getAttr('class');
            return cls.indexOf('debug') != -1;
        },
        
        loadHash: function(hash){
            var ss = hash.split('_');

            if (ss[0] == 'search'){
                if(ss.length>=2){
                    return loadSearchPage(decodeURIComponent(ss[1]));;
                }
            }else{
                return loadContentPage(hash);
            }
        }
    });
})