define(['../controller/home','./maker', '../shared/js-helper', './menu', './search'], function(ctrl, mk, hp, menu, search){
    return mk.extentView({
        init: function(_id, _parent){
            this.setBase(_id, _parent);
            
            var dom = '<div id=\'' + this.id + '\'></div>';
            hp.appendDomTo('#'+this.parent.id, dom);
            
            search.init('wrap_search', this);
            menu.init('wrap_menu', this);
        },
        
        getMenu: function(){
            return menu;
        },
        
        getSearch: function(){
            return search;
        }
        
    });
})