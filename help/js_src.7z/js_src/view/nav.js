define(['../controller/home','./maker', '../shared/js-helper'], function(ctrl, mk, hp){
    
    
    function generateNav(target){
        
        function makeLinkHtml(mh){
            return "<a class='cls_" + mh.name + 
            "' href='#" + mh.name + 
            "' flags='" + mh.flags + "'>" + mh.title + "</a>";
        }
        
        var s = [];
        
        for (var q = target; q != null; q = q.parent) {
            s.push(makeLinkHtml(q));
        }
    
        if (s.length > 0) {
            s[0] = target.title;
        }
        
        return s.reverse().join("&nbsp;&gt;&nbsp;");
    }
    
    return mk.extentView({
        init: function(_id, _parent){
            this.setBase(_id, _parent);
            
            var dom = '<div id=\'' + this.id + '\'>EastWave 帮助系统</div>';
            hp.appendDomTo('#'+this.parent.id, dom);
        },
        
        update: function(target){
            hp.sel('#'+this.id).setHtml(generateNav(target));
        }
    });
})