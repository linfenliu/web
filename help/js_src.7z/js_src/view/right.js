define(['../controller/home','./maker', '../shared/js-helper', './content'], function(ctrl, mk, hp, content){
    return mk.extentView({
        init: function(_id, _parent){
            this.setBase(_id, _parent);
            
            var dom = '<div id=\'' + this.id + '\'></div>';
            hp.appendDomTo('#'+this.parent.id, dom);
            
            content.init('wrap_content', this);
        },
        
        getContent: function(){
            return content;
        }
    });
})