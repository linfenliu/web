define(['../controller/home','./maker', '../shared/js-helper'], function(ctrl, mk, hp){
    return mk.extentView({
        init: function(_id, _parent){
            this.setBase(_id, _parent);
            
            var dom = '<input id=\'' + this.id + '\' type=\'text\' placeholder=\'Search EastWave Help...\'></input>';
            hp.appendDomTo('#'+this.parent.id, dom);
            
            hp.setEvent('keypress', '#'+this.id, function(e){
                if (e.keyCode == '13') {
                    
                    var hash = '#search_' + hp.sel(e.target).val();
                    
                    ctrl.changeHash(hash);
                }
            });
        }
        
    });
})