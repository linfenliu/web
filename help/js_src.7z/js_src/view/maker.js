define(['../shared/js-helper'], function(hp){
    return {
        view: function(){
            return {
                id: null,
                parent: null,
                
                setBase: function(_id, _parent){
                    this.id = _id;
                    this.parent = _parent;
                },
                
                resizeLayout: function(tb){
                    if(tb == null){
                        return;
                    }
                    
                    for(var key in tb){
                        hp.sel('#'+this.id).setCss(key, tb[key]);
                    }
                }
            }
        },
        
        extentView: function(extent){
            var tb = this.view();
            
            for(var key in extent){
                tb[key] = extent[key];
            }
            
            return tb;
        }
        
    }
})