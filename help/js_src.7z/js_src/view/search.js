define(['../controller/home','./maker', '../shared/js-helper', './input'], function(ctrl, mk, hp, input){
    return mk.extentView({
        init: function(_id, _parent){
            this.setBase(_id, _parent);
            
            var dom = '<div id=\'' + this.id + '\'></div>';
            hp.appendDomTo('#'+this.parent.id, dom);
            
            input.init('input_search', this);
        }
        
    });
})