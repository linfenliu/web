define(['../controller/home','./maker', '../shared/js-helper', '../model/mu-home'], function(ctrl, mk, hp, mu_home){
    
    var icon = {
        fold: ">",
        unfold: "&#8744"
    }
    
    function makeMenuHtml(mh){
        
        function makeLinkHtml(target)
        {
            return "<a class='cls_menu" + " cls_" + target.name + 
                "' href='#" + target.name + 
                "' flags='" + target.flags + "'>" + target.title + "</a>";
        }
        
        var s = "";
        
        if (mh.parent == null || mh.children.length == 0) {
            s += "<table width='100%'><thead><tr><td class='cls_menu_button_empty'><button href='javascript:void(0)'>&nbsp;</button></td><td>";
            s += makeLinkHtml(mh);
            s += "</td></tr></thead></table>";
    
            if (mh.parent == null) {
                for (idx in mh.children) {
                    s += makeMenuHtml(mh.children[idx]);
                }
            }
        } else {
            s += "<table width='100%'><thead><tr><td class='cls_menu_button'><button href='javascript:void(0)'>" + icon.fold + "</button></td><td>";
            s += makeLinkHtml(mh);
            s += "</td></tr></thead><tbody class='cls_menu_default_hide'>"
    
            for (idx in mh.children) {
                s += "<tr><td></td><td>" + makeMenuHtml(mh.children[idx]) + "</td></tr>";
            }
            s += "</tbody></table>";
        }
    
        return s;
    }
    
    
    return mk.extentView({
        init: function(_id, _parent){
            this.setBase(_id, _parent);
            
            var dom = '<div id=\'' + this.id + '\'>' 
            dom += makeMenuHtml(mu_home.getData());
            dom += '</div>';
            hp.appendDomTo('#'+this.parent.id, dom);
            
            hp.sel('.cls_menu_default_hide').hide();
            
            var this_view = this;
            
            hp.setEvent('click', '.cls_menu', function(e){
                ctrl.clickMenuText(hp.sel(e.target), this_view);
            });
            
            hp.setEvent('click', '.cls_menu_button', function(e){
                ctrl.btn_events['menu'](hp.sel(e.target), this_view);
            });
        },
        
        isHide: function(){
            return hp.sel('#'+this.parent.id).getCss('display') == 'none';
        },
        
        autoExpandMenu: function(sel){
            var text = sel.getText();
            
            if (text == hp.htmlDecode(icon.fold)){
                this.controlMenu(sel, "expand", "down", 0);
            }else if (text == hp.htmlDecode(icon.unfold)){
                this.controlMenu(sel, "contract", "down", 0);
            }
        },
        
        clickMenuText: function(sel){
            
            var flags = sel.getAttr('flags');
            
            var tr = sel.findSuperNode('tr');
            var btn = tr.getChildren(0);
            
             //展开节点，不打开本节点网页。
             if (flags & 1) {
                this.autoExpandMenu(btn);
                
                sel.setAttr('href', 'javascript:void(0)');
            }
            //展开节点，并打开本节点网页。
            else if (flags & 2) {
                this.autoExpandMenu(btn);
            }
        },
        
        hide: function(){
            var sel_left = hp.sel('#'+this.parent.id);
            var sel_right = hp.sel('#'+this.parent.parent.getRight().id);
            
            sel_left.fadeToggle('fast', function(){
                hp.sel('.button_expand').addClass('hide_state');
                
                sel_left.setCss('width', 0);
                sel_right.setCss('width', '100%');
                
                sel_right.animate({
                    left: 0
                });
            })
        },
        
        show: function(){
            var sel_left = hp.sel('#'+this.parent.id);
            var sel_right = hp.sel('#'+this.parent.parent.getRight().id);
            var left_size = this.parent.parent.parent.left_size
            
            sel_left.fadeToggle('fast', function(){
                hp.sel('.button_expand').removeClass('hide_state');
                
                var window_width = hp.getWindowWidth();
                var _left = hp.isSmallWebSize()? window_width : left_size;
                
                sel_left.setCss('width', _left);
                sel_right.setCss('width', window_width-_left);
                
                sel_right.animate({
                    left: _left
                });
            })
        },
        
        controlMenu: function(sel, action, dir, lv) {
        
            var node = sel;
            
            var expandContract = function (table) {
                var thead = table.getChildren(0);
                var tbody = table.getChildren(1);
                var prefix = thead;
                
                while (!prefix.is('button')) {
                    prefix = prefix.getChildren(0);
                }
                
                if (action == "expand" 
                && prefix.getText() == hp.htmlDecode(icon.fold)) //展开
                {
                    prefix.setHtml(icon.unfold);
                    tbody.fadeToggle('fast');
                } else if (action == "contract" 
                && prefix.getText() ==  hp.htmlDecode(icon.unfold)) //收缩
                {
                    prefix.setHtml(icon.fold);
                    tbody.fadeToggle('fast');
                }
            }
        
            if (dir == "up") {
                while (!node.is('body')) {
                    if (node.is('table')) {
                        expandContract(node);
        
                        if (lv-- == 0) break;
                    }
        
                    node = node.parent();
                }
            } else //往下
            {
                while (!node.is('body')) {
                    if (node.is('table')) {
                        expandContract(node);
        
                        if (lv == 0) return;
        
                        lv--;
                        break;
                    }
        
                    node = node.parent();
                }
                   
                var node_children = node.getChildren(1);
                var achild = node_children.getChildrens();
                for (var i = 0; i < achild.length; ++i) {
                    var a_ci = achild.getChildren(i);
                    var b_c1 = a_ci.getChildren(1);
                    var child = b_c1.getChildren(0);
                    
                    this.controlMenu(child, action, dir, lv);
                }
            }
        },
        
        toggleMenuVisible: function(){
            if (this.isHide()){
                this.show();
            }
            else{
                this.hide();
            }
        }
        
    });
})