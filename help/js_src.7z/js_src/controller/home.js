define(['../model/home'], function(home){
    
    var resize_event = null;
    var last_hash = null;
    
    return {
        hashEvent: function(interval, view){
            setTimeout(function () {
                
                var now_hash = window.top.location.hash.replace('#', '');
                var mu_home = home.getMuHomeObj().getData();
                
                
                if(now_hash == ''){
                    now_hash =  mu_home.name;
                    
                    var url = window.location.href.split('#')[0];
                    window.location.replace(url + "#" + now_hash);
                }
                
                if (last_hash != now_hash){
                    last_hash = now_hash;
                    
                    view.loadHash(last_hash);
                } 
                
                setTimeout(arguments.callee, interval);
            }, interval)
        },
        
        resizeEvent: function(interval, view){
            window.onresize = function () {
                if (resize_event) {
                    clearTimeout(resize_event);
                }
        
                resize_event = setTimeout(function () {
                    view.resizeLayout();
                }, interval);
            }
        },
        
        clickMenuText: function(sel, view){
            view.clickMenuText(sel);
        },
        
        changeHash: function(hash){
            window.location.hash = hash;
        },
        
        btn_events: {
            expand: function(view){
                view.toggleMenuVisible();
            },
            
            text: function(view){
                view.changeFontSize(15, 21, 2);
            },
            
            style: function(view){
                view.changeStyle();
            },
            
            reload: function(){
                window.open('./reload.ewsl','_parent');
            },
            
            release: function(){
                window.open('./reload.ewsl?q=release','_parent');
            },
            
            menu: function(sel, view){
                view.autoExpandMenu(sel);
            }
        }
        
    }
    
})